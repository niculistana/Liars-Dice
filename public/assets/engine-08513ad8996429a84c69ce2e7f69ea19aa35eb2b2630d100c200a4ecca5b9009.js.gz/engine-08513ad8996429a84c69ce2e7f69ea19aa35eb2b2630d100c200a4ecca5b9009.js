// var numPlayers = 0;
// var players = [];
// var assetsLoaded = false;
// var hasWinner = false;

// loop until engine(game).numPlayers = 4
function isRoomFull() {
    if (numPlayers === 4) {
        return true;
    } else {
        return false;
    }
}

// once done, update engine(game).assetsLoaded == true
function isLoaded() {
    if (assetsLoaded) {
        return true;
    } else {
        return false;
    }
}

// loop until engine(game).hasWinner == true
function isContinue() {
    if (hasWinner) {
        return true;
    } else {
        return false;
    }
}

// update diePool depending on engine(game) rules...
function updateGlobalPool(game) {
  
}
