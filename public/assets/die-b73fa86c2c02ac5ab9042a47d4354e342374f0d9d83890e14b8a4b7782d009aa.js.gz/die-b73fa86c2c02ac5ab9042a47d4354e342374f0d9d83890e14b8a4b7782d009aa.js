// contains information about the die
// plural, dice[]

// id
// Sprite
// Sound
// Physics

function Die (id) {
  this.id = id;
}
