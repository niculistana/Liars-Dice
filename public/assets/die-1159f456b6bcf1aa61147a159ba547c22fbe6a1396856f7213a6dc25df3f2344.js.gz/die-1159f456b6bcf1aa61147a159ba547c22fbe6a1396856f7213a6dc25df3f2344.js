// contains information about the die
// plural, dice[]

// Value
// Sprite
// Sound
// Physics

function Die (value) {
  this.value = value;
}
